#include <bits/stdc++.h>
#include <chrono>
using namespace std;
#define int long long
#define pi 3.141592653
constexpr int am_gn = 1e4+7;
template<typename T> istream &operator>>(istream &zgs_ngn, vector<T> &fnc_h){ for (auto &k_eyw : fnc_h) zgs_ngn >> k_eyw; return zgs_ngn; }
string y_jmf;
int ps[am_gn],A[10000];
int n;
//ð ð
void fs_r(){
    int a,b,c; cin >> a >> b >> c;
    int sum = a+b+c;
    if(sum%9){
        cout << "NO";
        return;
    }
    int ans = sum/9;
    if(a<ans || b<ans || c<ans){
        cout << "NO";
    }else cout << "YES";
}

int32_t main(void){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
       // sieve();
    int t; cin >> t;
    while(t--){
    fs_r();
       // if(temp.count(n))
        cout << endl;
    }
}